import signal
import sys, os
import errno

class HandleInterrupt:
  
    def __init__(self, display):
        self.display = display
        signal.signal(signal.SIGINT,  self.exit)
        signal.signal(signal.SIGTERM, self.exit)
        signal.signal(signal.SIGUSR1, self.rChildSig)
        signal.signal(signal.SIGCHLD, self.endZChildProcs) # Kill zombie children
    
    # Handle for child to signal parent
    def signalParent(self):
        os.kill(os.getppid(), signal.SIGUSR1);
    
    # Signal sent to parent to redraw    
    def rChildSig(self, signum, frame):
        self.display.draw() 

    def exit(self, signum, frame):
        print("\nProgram closing...\n")
        sys.exit(1)
        
    def addChild(self, amount = 1):
        self.activeChildren += amount
        self.display.draw(self.activeChildren)
        
    # end zombie child processes
    def endZChildProcs(self, sig,frame):
        while True:
            try:
                pid, status = os.waitpid(-1, os.WNOHANG)
                
                if pid == 0: 
                    break
            
            except OSError:
                pass
            
            finally:
                try:
                    # check if pid exsists
                    os.kill(pid, 0)
                except os.error, (err, errstr):
                    if err != errno.ESRCH:
                        raise
                    # increment children processes ended
                    self.display.updateActiveProcs(-1)
                else:
                    print("Error: Could not end zombie process " + str(pid))
                
                break

                       
                
