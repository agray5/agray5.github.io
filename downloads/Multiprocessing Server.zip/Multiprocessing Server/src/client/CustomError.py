class FileLocked(Exception):  
    pass 
    '''  
    def __init__(self, arg = "File is locked"):
        self.strerror = arg
        self.args = {arg}
    '''
class Disconnected(Exception):
    pass
    '''     
    def __init__(self, arg = "Disconnection has occured"):
        self.strerror = arg
        self.args = {arg}
    '''
        