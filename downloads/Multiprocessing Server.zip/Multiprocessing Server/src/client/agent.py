from __future__ import print_function
import sys
import errno
import os
import socket
import time
import threading

from networking import send, recvAll
from handleInterrupt import HandleInterrupt
from agentDisplay import AgentDisplay
from agentParseCommFile import parseCommFile
from parseCommand import parseCommand
from Msg import Msg
from CustomError import Disconnected, FileLocked


display = None
lastFlight = None


def createSocket(host, port):
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.connect((host, port))
    return sock
    

def connect(host, port):
    listen_socket = createSocket(host, port)
    return listen_socket
    
    
def runCommand(command, socket):
    comm = command["command"]
    
    # Catch commands that don't go to the server
    
    # Most likely the user pressed enter with no input 
    if comm == "None":
        return False
    # Help redisplays instructions 
    if comm == "HELP":
        display.hasSeenInstructions = False
        return False
    
    # Special handling for the Reserve command
    if command["command"] == "R":
        # The reserve command requires there to be a past flight queried
        if lastFlight == None:
            display.loadMsg("You must query a flight first.")
            return False
        # Can the command into one the server understands
        seats = ""
        for seat in command["seats"]:
            seats += "" + str(seat) + " "
        
        # Transform Command R    
        command["commandStr"] = "S " + str(lastFlight) + " " + seats + " " + command["customer"]

    send(socket, command["commandStr"])
    
# Run our program until stopped 
def run(socket, host, port):
    while True:
        # Draw the current screen
        display.draw()
        # Get User input
        usrInput = display.acceptInput()
        # process user input
        command = parseCommand(usrInput)
        
        # Display any messages onto the screen
        if isinstance(command, Msg):
            display.loadMsg(command.msg)
            
        # Run what ever our command is
        else:
            
            # keep track of last flight
            if "flight" in command:
                global lastFlight
                lastFlight = command["flight"]
            
            # nothing to send to server
            if runCommand(command, socket) == False:
                continue
            
            try:
                try:
                    # recieve complete message from server
                    data = recvAll(socket)
                except FileLocked:
                    if not waitForFile(socket):
                        continue
                
                # Draw feedback from server
                display.drawFeedback(data)
                
            
            except Disconnected:
                # reconnect if we become disconnected
                socket = connect(host, port)
     
# Handle user input in a seperate thread
def getUsrInput():
        usrIn = "n"
        global unLocked
        global canceled
        
        while True:
            usrIn = raw_input("<@> ")
            
            if usrIn.upper() == 'C':
                break
            
        canceled = True

# Implements a system to handle the file locked case
canceled = False
unLocked = False    
usrInput = []           
def waitForFile(sock):
    global unLocked
    unLocked = False
    # Temporialy turn the socket to be nonblocking
    sock.settimeout(.1)
    
    # Start thread to handle user input
    inputThread = threading.Thread(target = getUsrInput, args = (usrInput))
    inputThread.daemon = True
    
    # Prompt user to wait
    display.draw()
    print( "\nWaiting for file to unlock. Enter 'C' to cancel.\n")
    
    # Start thread
    inputThread.start()
    
    # Loop until either user cancels or data returns somthing
    while True:
        global canceled
        if canceled:
            display.loadMsg("\nPlease enter 'c' to continue")
            display.draw()
            inputThread.join()
            sock.settimeout(None)
            return False
        try:
            data = recvAll(sock, False)
            display.loadMsg("\nPlease enter 'c' to continue")
            display.draw()
            inputThread.join()
            sock.settimeout(None)
            return data
            
        except socket.timeout:
            time.sleep(0.1)
    

def main():
    # set up handler for system interrupts
    
    fileInfo = parseCommFile(1)
    
    # Set display for agent
    global display 
    display = AgentDisplay()
    
    # set up class to handle interrupts 
    interrupter = HandleInterrupt(display)
    
    try:
        # create socket
        sock = connect("localhost", fileInfo["port"])
        
        # run program
        run(sock, "localhost", fileInfo["port"])
    
    #  Print error message if agent cant connect to server
    except socket.error as err:
        if err.errno == errno.ECONNREFUSED:
            print ("Error: Server is unavailable at this time.")
            
    # Catch keyboard interrupts
    except KeyboardInterrupt:
        print("Session ended...\n")
        try:
            sys.exit(0)
        except SystemExit:
            os._exit(0)
        
        
    


if __name__ == "__main__":
    main()
