from Msg import Msg

class Display:
    
    loadedMsg = []
    loadedMsgLimit = 4
    
    def __init__(self):
        pass
    
    def acceptInput(self):
        # Get user input
        usrInput = raw_input("\n<@> ")
        # Return input
        return usrInput
    
    # Wraps each string into a Msg
    # Also maintains how many messages can be dislayed at a time
    def loadMsg(self, msg, error = False):
        message = Msg(msg, error)
        self.loadedMsg.append(message)
        if len(self.loadedMsg) > self.loadedMsgLimit:
            self.loadedMsg.pop(0)
    
    # Prints all messages in queued and then clears list
    def printLoadedMsg(self):
        # print optional Message
        if self.loadedMsg and len(self.loadedMsg) > 0:   
            for msg in self.loadedMsg:
                print(msg.msg)
        self.clearLoadedMsg()
    
    # Empties message list
    def clearLoadedMsg(self):
        self.loadedMsg = []
        
    # prints multiple lines
    def printlns(self, strings):
        for string in strings:
            print(string)
        
        
