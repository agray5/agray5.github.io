from CustomError import Disconnected, FileLocked

end = "{0}"
# Add an end signifier to message
def send(socket, msg):
    
    msg += end
    encodedMsg = msg.encode()
    
    socket.send(encodedMsg)

            
# Make sure we receive complete message     
def recvAll(socket, discardExtra = True):
    msg = ''
    data = ''
    
    # Loop until we receive complete message
    while True:
        data = socket.recv(8192).decode()
        
        # No processing needed if file is locked
        if "locked" in data:
            raise FileLocked
        
        # Empty string means we got disconnected
        if not data:
            raise Disconnected
        
        # '{1}' may be added to an incoming message.
        # It is added as a safety measure, 
        # in the case of a file lock the server 
        # may send information after a client has canceled
        # If the client does not want to keep 
        # this extra information discard it
        if "{1}" in data and discardExtra:
            endPos = data.find(end)
            data = data[endPos+3:]
            
        # In the case that we want to keep the message
        # Just discard the beginning {1}
        if "{1}" in data:
            endPos = data.find("{1}")
            data = data[3:]
        
        # We have received the last of the message
        if end in data:
            endPos = data.find(end)
            msg += data[:endPos]
            nextMsg = data[endPos:]
            
            splitMsg = msg.split()
            
            return {
                "commandStr": msg,
                "commType": splitMsg[0],
                "msg": splitMsg[1],
                "remainder": nextMsg
                }
        # Not all of the message have been recieved
        msg += data
        