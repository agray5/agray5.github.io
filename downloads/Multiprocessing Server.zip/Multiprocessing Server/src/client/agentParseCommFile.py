def parseCommFile(num):    
    # begin read in of our agent file 
    # This file contains at host address and port number
    # It may also contain commands to execute the client
    file = open("agent"+str(num)+".dat", "r")
    
    host = file.readline() # The first line is expected to be the host address
    port = file.readline() # The second line should be port number
    
    # We end our reading of the agent file
    file.close() 
    
    return {
        "host": host, 
        "port": int(port)
        }