from Msg import Msg

def parseCommand(commandStr, isServer = False):
    
    # List of valid commands
    validCommands = ["Q", "R", "C", "Q", "S", "HELP"]
    
    if commandStr == "":
        return {
            "command": "None"
            }
            
    # Get the parts of the command as an array
    command = commandStr.split()
    
    # Remove case ambiguity
    commType = command[0].upper()
    
    if isServer:
        return parse(commType, command, commandStr)
    
    
    # Test for validity 
    if not commType in validCommands: 
        return Msg("Error: " + command[0] + " is not a supported command.", True);
    
    elif commType == "Q" and len(command) != 2:
        return Msg("Error: " + command[0] + " requires exactly 1 argument.", True);
    
    elif commType == "R" and len(command) < 3:
        return Msg("Error: " + command[0] + " requires at least 2 arguments.", True);
    
    elif commType == "C" and len(command) != 3:
        return Msg("Error: " + command[0] + " requires exactly 2 arguments.", True);
    
    
    parsedComm = parse(commType, command, commandStr)
    
    # Check that flight is valid
    if "flight" in parsedComm:
        if int(parsedComm["flight"]) < 1 or int(parsedComm["flight"]) > 4:
            return Msg("Error: flight number " + str(parsedComm["flight"]) + " is not available. Please list a flight between 1-4.")

    return parsedComm

# Switch clause for each command
def parse(commType, command, commandStr):
    if commType == "Q":
        return { 
            "flight": int(command[1]),
            "commandStr": commandStr,
            "command": commType,
            }
    
    elif commType == "R":
        return { 
            "commandStr": commandStr,
            "command": commType,
            "customer": command[len(command) - 1],
            "seats": intArray(command[1:len(command) - 1])
            }
        
    elif commType == "C":
        return {
            "commandStr": commandStr,
            "command": commType,
            "flight": int(command[1]),
            "customer": command[2]
            }
    
    elif commType == "S":
        return {
            "commandStr": commandStr,
            "command": commType,
            "flight": int(command[1]),
            "customer": command[len(command) - 1],
            "seats": intArray(command[2:len(command) - 1])
            }
    
    # If the command is not listed but is valid
    else:
        return {
            "commandStr": commandStr,
            "command": commType
            }
    

def intArray(array):
    intarr = []
    
    for obj in array:
        intarr.append(int(obj))
        
    return intarr
    
    
    
    