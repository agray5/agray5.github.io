# A class to encapsulate messages to be sent to the display
class Msg:
    def __init__(self, msg, isError=False):
        self.msg = msg
        self.error = isError
