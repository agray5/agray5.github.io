from Display import Display
from CustomError import FileLocked

class AgentDisplay(Display):
    
    screen = None
    hasSeenInstructions = False
    
    def __init__(self):
        Display.__init__(self)
        self.screen = "main"
      

    def draw(self):
        
        print("\033[H\033[J")
        
        if self.screen == "main" :
            print("Welcome to the Adirondack Air Flight Manager!")
            
            # Do not display instruction twice unless asked
            if not self.hasSeenInstructions: 
                print("The commands available to you are listed below:")
                self.printlns([
                    "\nTo Query Available Seats:",
                    "Q [x]",
                    "Example useage:",
                    "'Q 1' | This command would query if there are available seats on flight 1",
                    "\nTo Reserve Seats For a Customer:",
                    "R [i j ...] [n]",
                    "Example useage:",
                    "'R 1 4 3 Jones' | This command would attempt to reserve the selected seats for the named customer",
                    "\nTo Cancel Seats For a Customer: ",
                    "C [x] [n]",
                    "Example useage:",
                    "'C 1 Jones' | This command would remove all seats assigned to the named customer",
                    "\nRedisplay commands: ",
                    "'Help'\n"
                    ])

                # We have seen instructions
                self.hasSeenInstructions = True
                
            self.printLoadedMsg()
        
    
    def drawFeedback(self, data):
        self.loadMsg("\n")
        
        if(data["commType"] == "Q"):
            if(data["msg"] == 1):
                self.loadMsg("There is " + data["msg"] + " seat are available")
            else:
                self.loadMsg("There are " + data["msg"] + " seats are available")
        
        elif(data["commType"] == "R"):
            self.loadMsg("Seats have been successfully reserved.")
            
        elif(data["commType"] == "C"):
            self.loadMsg("Seats have been successfully cancelled.")
        
        
    def resetMenu(self):
        self.screen = "main"
        


    