import fcntl
import errno
from CustomError import FileLocked

# Each seat is one line of the database
# The key for each entry is the tuple (seat, flight)
# 
# Database columns:
# seat flight isReserved customer 
# customer can be null if isReserved flag is set to 0
class Database:
    
    # database file name
    dbFile = ""
    # seats count for flights 1 - 4
    flightLineStart = [1, 6, 8, 18]
    seatsInFlight = [5, 2, 10, 10]
    
    locked = False
    
    def __init__(self, log):
        self.dbFile = "database.dat"
        self.log = log
        
    # Performs the read from file functions on database
    # Returns information about each seat queried
    # Param flightsWithSeats is written as such: 
    # {1: [1, 2], 3: [2, 3]... }
    # Each key in dictionary is the flight 
    # Each array are the seats to be queried
    # If the all param is true it will instead check all the seats
    def readSeatInfoFromFile(self, flightsWithSeats, all = False):
        with open(self.dbFile,'r') as f:
            lines = f.readlines()
            flights = {}
            for fght in (range(len(self.seatsInFlight)) if all else flightsWithSeats):
                flight = []
                for seat in (range(self.seatsInFlight[int(fght)]) if all else flightsWithSeats[fght]):
                    num =  0 if all else -1
                    num2 = 0 if all else -1
                    entryNum = self.flightLineStart[int(fght) + num2] - 1 + seat + num
                    
                    seatInfo = lines[entryNum]
                    seatInfo = seatInfo.split()
                    flight.append(
                        {
                            "seat": int(seatInfo[1]),
                            "flight": int(seatInfo[0]),
                            "isReserved": int(seatInfo[2]),
                            "customer": seatInfo[3]
                            })
                flights[fght] = flight
        
            return flights
            
        
    # Create an array of arrays for each flight, which hold dictionaries for each seat
    def getAllSeatInfo(self):
        flights = self.readSeatInfoFromFile(None, True)
       
        return flights
        
    # returns all information about a specfic seat
    def getSeatInfo(self, seat, flight):
        
        flightInfo = self.readSeatInfoFromFile({
                                            str(flight): [int(seat)]
                                            })
        return flightInfo[str(flight)][0] 
    
    # returns if a seat is reserved
    def seatIsReserved(self, seat, flight):
        seatInfo = self.getSeatInfo(seat, flight)
        
        return seatInfo["isReserved"]
    
    # Checks all available seats in a flight
    def availableSeats(self, flight):
        
        # seat count
        available = 0
        
        # Checks if each seat is available 
        for i in range(self.seatsInFlight[flight-1]):
            if not self.seatIsReserved(i+1, flight):
                available += 1
        
        return available
     
    # All writes to the database are done here
    def updateDB(self, type, seats, flight, customer): 
        customer = customer.upper()
        
        # read in database file
        with open(self.dbFile, 'r') as file:
            
            # Before we update database see if file is locked
            try:
                fcntl.flock(file, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except IOError as e:
                # raise on unrelated IOErrors
                if e.errno != errno.EAGAIN:
                    raise
                else:
                    file.close()
                    raise FileLocked
        
            
            # read a list of lines into data
            data = file.readlines()
            
        # If seats is not an array, change seats into an array
        if not isinstance(seats, list):
            seats = [seats]
        
        # Line numbers of seats
        baseLineNumber = self.flightLineStart[flight-1] - 1
               
        for i in range(len(seats)):
            lineNumber = baseLineNumber + int(seats[i]) - 1
            
            # Change line based on update type
            if type == "reserve":
                data[lineNumber] = "" + str(flight) + " " + str(seats[i]) +  " 1 " + customer + "\n"
            elif type == "cancel":
                data[lineNumber] = "" + str(flight) + " " + str(seats[i]) +  " 0 " + "null" + "\n"
                
        # write updated database file
        with open(self.dbFile, 'w') as file:
            file.writelines(data)
            # We are done writing to the file so unlock it
            fcntl.flock(file, fcntl.LOCK_UN)   
        
    # Handles reserve seat command
    def reserveSeats(self, seats, flight, customer): 
        customer = customer.upper()
        
        classSeats = self.classifySeats(seats, flight)

        self.updateDB("reserve", classSeats["free"], flight, customer)
        
        return classSeats["reserved"]
        
    # Divides given seats into free and reserved
    def classifySeats(self, seats, flight):
        rsrvdSeats = []
        flight = int(flight)
        
        for seat in seats:
            if self.seatIsReserved(seat, flight):
                rsrvdSeats.append(seat)
                
        return {
            "free": [x for x in seats if x not in rsrvdSeats],
            "reserved": rsrvdSeats
            }
        
    # Handles cancel command 
    def cancelSeats(self, flight, customer):
        customer = customer.upper()
        
        seats = []
        with open(self.dbFile, 'r') as file:
            for line in file:
                if str(flight) in line and customer in line:
                    seat = line.split()
                    seats.append(seat[1])
                    
        classSeats = self.classifySeats(seats, flight)
        
        self.updateDB("cancel", classSeats["reserved"], flight, customer)
        
        return classSeats["free"]
        
            
            
            
            