import socket
import os
import errno
import sys
import logging
import time

from networking import send, recvAll
from handleInterrupt import HandleInterrupt
from serverDisplay import ServerDisplay
from Database import Database
from Msg import Msg

from parseCommand import parseCommand
from CustomError import FileLocked, Disconnected


# Host and port
HOST, PORT = '', 8888

# max connections to listen for 
listenNum = 10 

display = None

# Handle connection
def handle(socket, db):
    try:
        # Run until error or disconnected from client
        while True:
            try:
                msg = recvAll(socket)["commandStr"]
                
            except Disconnected:
                break
            
            # Parse command
            command = parseCommand(msg, True)
            
            # Run recieved command
            runCommand(command, socket, db)
            
            # Signal parent to redraw screen
            interrupter.signalParent()
            
        socket.close()
    except:
        log.exception("An error occured while handling a connection.")
        pass
    finally:
        socket.close()

# Handle the recived command
def runCommand(command, socket, db):
    
    if isinstance(command, Msg):
        print(command.msg)
        return
            
    commType = command["command"].upper()
    
    if "flight" in command:
        command["flight"] = int(command["flight"])
    
    if commType == "Q":
        seats = db.availableSeats(command["flight"])
        send(socket, "Q "+str(seats))
    
    elif commType == "R":
        try:
            alreadyRsrvdSeats = db.reserveSeats(command["seats"], 1, command["customer"])
        except FileLocked:
            if not retryLockedFile():
                return
        seats = " y "
        # Turn array into a string
        for seat in alreadyRsrvdSeats:
            seats += str(seat) + " "
        send(socket, "R "+seats)
        
    elif commType == "C":
        eStr = ""
        try:
            alreadyFreeSeats = db.cancelSeats(int(command["flight"]), command["customer"])
        except FileLocked:
            send(socket, "locked")
            alreadyFreeSeats = retryLockedFile(commType, command)
            if not alreadyFreeSeats():
                return
            else :
                eStr = "{1}"
        seats = " y "
        # Turn array into a string
        for seat in alreadyFreeSeats:
            seats += str(seat) + " "
        send(socket, eStr + "C "+seats)
    
    elif commType == "S":
        eStr = ""
        try:
            alreadyRsrvdSeats = db.reserveSeats(command["seats"], command["flight"], command["customer"])
        except FileLocked:
            alreadyFreeSeats = retryLockedFile(commType, command)
            if not alreadyFreeSeats():
                return
            else :
                eStr = "{1}"
        seats = " y "
        # Turn array into a string
        for seat in alreadyRsrvdSeats:
            seats += str(seat) + " "
        send(socket, eStr+"R "+seats)
    
    # Keep retrying command until file is unlocked
    def retryLockedFile(commType, command):
        while True:
            try:
                if commType == "C":
                    alreadyFreeSeats = db.cancelSeats(int(command["flight"]), command["customer"])
                elif commType == "S": 
                    alreadyRsrvdSeats = db.reserveSeats(command["seats"], command["flight"], command["customer"])
            
                return alreadyRsrvdSeats
            except FileLocked:
                time.sleep(0.1)
    
# Log errors from child
def initLogger():
    global log
    log = logging.getLogger('server_logger')
    log.setLevel(logging.DEBUG)
    fh = logging.FileHandler('server.log')
    fh.setLevel(logging.DEBUG)
    ch = logging.StreamHandler()
    ch.setLevel(logging.ERROR)
    formatter = logging.Formatter('\n[%(asctime)s - %(levelname)s]: %(message)s')
    fh.setFormatter(formatter)
    ch.setFormatter(formatter)
    log.addHandler(fh)
    log.addHandler(ch)

def main():
    # Set up debugging file
    initLogger()
    
    db = Database(log)
    
    global display
    display = ServerDisplay(db)
    
    try:
        global interrupter
        interrupter = HandleInterrupt(display)  
        interrupter.log = log    
        
        # set up socket
        listen_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    
        # set up socket for reuse
        listen_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    
        # bind socket
        listen_socket.bind((HOST, PORT))
        
        # start listening
        listen_socket.listen(listenNum)
        
        display.draw()
        
        # create a child process for each connection
        while True:
            # accept connection
            try: 
                conn, client_address = listen_socket.accept() 
            # ignore system interrupt
            except (OSError, IOError) as e:
                    if e.errno == errno.EINTR:
                        continue
                    raise
                    
            # fork child process
            pid = os.fork()
            
            # Fork has failed
            # Client must try to reconnect
            if pid < 0:
                conn.close()
                print("Error: Could not fork child")
                continue  
            
            ## Child process
            if pid == 0:
                # close listening socket
                listen_socket.close()
                try:
                    handle(conn, db)
                except Exception as e:
                    log.exception("Child proccess raised an exception.")
                    raise
                finally:
                    log.debug("Child exited")
                    os._exit(0)
                
            ## Parent process
            
            # Close connection to client
            conn.close()
            
            # Increment active child process
            display.updateActiveProcs()
            
            display.draw()
    
    except KeyboardInterrupt:
        print("Server shutting down...\n")
        
        try:
            sys.exit(0)
        except SystemExit:
            os._exit(0)

            
        
        
if __name__ == "__main__":
    main()
    
    
    
