from Display import Display


class ServerDisplay(Display):
    
    db = None
    activeProcs = 0
    
    def __init__(self, database):
        Display.__init__(self)
        self.db = database
        

    def draw(self):
        print("\033[H\033[J")
    
        
        print("Active Users: " + str(self.activeProcs))
        self.drawDBTable()
        self.printLoadedMsg()
    

    def updateActiveProcs(self, amount = 1):
        self.activeProcs += amount
        self.draw()
        
    def drawDBTable(self):
        
        # Table header
        print("Flight   Seat   Reserved   Customer")
        print("___________________________________")      
        
        # Fill in table
        info = self.db.getAllSeatInfo()

        for flightNum, flight in info.iteritems():
            for seat in flight:
                string = " "
                string += str(seat["flight"]) + " "*7
                string += str(seat["seat"]) +  (" "*6 if seat["seat"] >= 10 else " "*7)
                string += (" Yes" + " "*6) if int(seat["isReserved"]) == 1 else (" No" + " "*8)
                string +=  " " + str(seat["customer"]) if not str(seat["customer"]) == "null" else "None"
                print(string)
    
    
        
