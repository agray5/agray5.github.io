##  Multiprocessing Server 

---

A project for made for a Networks course, the goal is to create a server and client program for an airline. 

The server displays each flights seats, whether the seats are reserved, and the customer that reserved them. Multiple agents, the client program, can run at once. An agent can query how many seats are available on a flight, reserve multiple seats on the last queried last flight, and cancel seats for a customer on a specified flight.

### Requirments

This program is built to run on Linux. It may run on Window's Bash Shell but that has not been tested. 

### Usage

---

#### Running from executable

The executable files are located in the 'dist' folder. 

First open a terminal and make sure the directory is the 'dist' folder. 

```
$ cd dist  # Assuming your directory is the root project folder
```

The server and agent are sperate programs and will need to be executed in seperate terminal windows. 

```
$ ./server # Starts the server
```

```
$ ./agent  # Starts an agent 
```



#### Running from source

Simular to [Running from executable](#running-from-executable) a terminal will need to be opened for each program to be run but this time from the 'src' folder. 

```
$ cd src           # Assuming your directory is the root project folder
```

```
$ python server.py # Starts the server
```

```
$ python agent.py # Starts an agent
```

